all this batch file does is make a few folders and some txt files, nothing too complicated. if you want you can edit the file yourself to see the full things
it does. not gonna label it all lol but im gonna make a legend:

mkdir - makes the folders
cd - changes folders
fsutil - makes the fake .txt files